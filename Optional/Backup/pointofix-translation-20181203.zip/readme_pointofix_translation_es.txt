
Pointofix paquete de Idiomas
-------------------------------------------

Incluye los ficheros de traducci�n siguientes los cuales pueden ser editados mediante un editor de textos.

(orden alfab�tico)

- pointofix_translation_ar.ini - �rabe
- pointofix_translation_zh-cn.ini - Chino
- pointofix_translation_hr.ini - Croata
- pointofix_translation_es.ini - Espa�ol
- pointofix_translation_fr.ini - Franc�s
- pointofix_translation_el.ini - Griego
- pointofix_translation_nl.ini - Holand�s
- pointofix_translation_hu.ini - H�ngaro
- pointofix_translation_en.ini - Ingl�s
- pointofix_translation_it.ini - Italiano
- pointofix_translation_jp.ini - Japon�s
- pointofix_translation_pl.ini - Polaco
- pointofix_translation_pt-br.ini - Portugu�s de Brasil
- pointofix_translation_se.ini - Sueco
- pointofix_translation_zh-tw.ini - Taiwan�s / Chino
- pointofix_translation_tr.ini - Turco


- Alem�n: 
No se necesita archivo de traducci�n, es el idioma por defecto.



C�mo usar el paquete de idiomas de Pointofix
-------------------------------------------------------------------

1) Primero instalar la versi�n alemana de Pointofix 1.8.0.2017.02.18 (o superior)

2) Luego copiar el archivo de traducci�n deseado (por ejemplo "pointofix_translation_es.ini"
para la versi�n espa�ola) desde el paquete de idiomas al directorio donde est� Pointofix
(por ejemplo "C:\Program Files\Pointofix\").

3) Cambiar el nombre al fichero por "pointofix_translation.ini"
(por ejemplo "pointofix_translation_es.ini" -> "pointofix_translation.ini")

4) Despu�s reiniciar Pointofix. �Listo!

Atenci�n: Si tu sistema windows no muestra las extensiones de ficheros, entonces deber�s recordar, que existe una diferencia entre el nombre del fichero que ves y el nombre real del fichero. Por ello si tu idioma no funciona, intenta borrar la extensi�n ".ini" y dejar solo el nombre del fichero como "pointofix_translation" porque tu sistema a�adir� la extensi�n ".ini" autom�ticamente.


�Traducci�n a tu idioma?
-------------------------------------

Cualquier traducci�n a otro idioma es bienvenida.
Si te gusta traducir, utiliza el archivo de traducci�n en ingl�s pointofix_translation_en.ini
como plantilla y env�a tu archivo a info@pointofix.de para compartirlo con otros.
Gracias.

www.pointofix.de